# SurvEye changelog

All notable changes to SurvEye (Stata command `surveye`) and its former
development names are documented here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and releases use
semantic versioning.

## [Unreleased]

## [2.2.0] — 2026-07-27

Reader-facing feature release. Every addition works inside the existing
self-contained HTML output; no new Stata options and no runtime network
dependency are introduced. The release-specific engine is now
`surveye_2_2_0.jar`.

### Added — SurveyCTO questionnaires
- `surveye`, `surveye describe`, and `surveye demo` now accept SurveyCTO
  questionnaires alongside Survey Solutions previews, detected by content
  rather than file extension. The ODK XForm form definition (XML) is parsed
  precisely: titles, top-level groups as sections, nested groups as
  subsections, repeats (flagged), binds and types, inline choice items,
  itemsets over secondary instances, jr:itext translations (default
  language), notes (skipped), and calculate fields (charted when typed).
- SurveyCTO split select_multiple exports (`field_1`, `field_2`, ...) are
  reassembled into multiselect charts automatically; single_one filters,
  demo simulation, GPS candidates, and the profile table all work unchanged.
- The printable SurveyCTO HTML form is read directly, certified against a
  real production export: the printed Field/Question/Answer table, dark
  top-level group rows as sections, breadcrumb subgroup rows (including
  "(Repeated group)") as subsections with repeat scope, spacer-based
  nesting depth, nested choice tables with codes and labels, relevance
  captured as conditions, and hints kept out of labels. Printables do not
  encode field types, so choice fields import as select_one and open,
  note, or calculated fields as text; display-only notes drop
  automatically when no data column matches, and one warning explains all
  of it. Detection also recognizes the table layout structurally, so
  exports that never mention SurveyCTO by name still parse. Panel
  subtitles now show reader-facing type captions ("single-select",
  "numeric decimal", "choice list") instead of internal tokens.
  Unrecognized layouts fail with directions to the fully supported XML
  definition. `tests/run_surveycto_tests.sh` covers describe, build, demo,
  the printed table layout end to end, both negative paths, and Survey
  Solutions regression, and runs in CI.

### Documentation
- The README opens with a screenshot gallery (`docs/screenshots/`): the
  Sri Lanka 2026 informal-sector fieldwork dashboard masthead (forest
  theme, byline, live filter count), `surveye demo` on the full B-READY
  2025 Australia instrument with a simulated section of results, and an
  informal-sector module band whose chart values are simulated so no
  preliminary fieldwork results circulate.

### Fixed
- Refreshing the GitHub repository through the web uploader (which never
  deletes files) could leave the retired `surveye_2_1_3.jar` and the old
  workflow in place, failing CI with a cryptic `cmp` byte difference.
  `tests/check_package.sh` now fails any stale `surveye_*.jar` with an
  explicit message and the web-UI removal steps, the workflow runs that
  check before the raw `cmp`, and `GITHUB_UPLOAD.md` documents the removed
  files, the hidden-`.github` caveat, and an exact `git` mirror recipe.
- The help file contained three physical lines over 244 characters, which
  Stata's viewer corrupts by dropping 8-byte chunks at 256-byte boundaries
  (rendering, e.g., `digital_channel` as `digi nel`), plus one `{it:...}`
  directive spanning a line break, which SMCL forbids. All example commands
  are rewrapped with `{cmd:...}` closed and reopened per physical line, and
  `tests/check_stata_source.sh` now fails on any help line over 244
  characters or any line that leaves an SMCL directive open.
- Runtime dark mode now works under every theme and finish: the editorial
  finish palette is scoped `:not([data-theme="dark"])` so toggling dark on a
  default (editorial) build no longer mixes the cream palette into the dark
  one, and dark-specific overrides were added for the sticky top bar, active
  section-navigation pill, pressed filter chips, the mobile filter toggle,
  and the benchmark-row rule — all previously navy-on-near-navy. Toggling a
  dark-built dashboard switches to the light World Bank base and back.

### Added — devices adopted from the ISES house style
- `byline("Label|Name|Role|Email")` signs the masthead cover with a task-team
  attribution block (label pill, name, role, mailto link) in build and demo
  modes; all parts optional, Arabic-script aware, styled for print.
- Emphasis syntax in `title()` and `subtitle()`: a pair of asterisks renders
  as a cyan accent in the title and bold in the subtitle, while the browser
  tab title and language detection see plain text.
- The stratum profile table gains table-lens micro-bars under every share
  cell (absolute 0–100 scale; gold on the benchmark row) and a filled-navy
  uppercase header row; both restyle in dark mode and flatten for print with
  forced bar colors.
- The top bar carries a dim gold track that the cyan-to-gold reading-progress
  bar fills as the page scrolls, and section-navigation hover picks up the
  cyan tint.

### Changed — visual identity
- The dashboard typeface is now Public Sans (SIL OFL 1.1), embedded as a 34 KB
  Latin variable-weight WOFF2 so files stay fully offline; true tabular
  numerals now apply to every KPI, table, and axis. Arabic and Urdu interfaces
  keep their Noto stacks, and the `typography(editorial|modern|system)` finish
  options remain available as explicit overrides.
- The hero is a deep-navy cover card with a faint sampling-grid graticule and
  an animated cyan-to-gold base rule; the same spectrum now forms the topline
  and the reading-progress bar. The sticky controls card straddles the cover's
  bottom edge.
- Warm archival paper (the SurvEye/ISES house `#FBFAF6`) with warm hairlines
  and soft fills, under navy-keyed ink and shadows — the print-report ground
  the navy cover and gold accents sit on. Chart data colors are unchanged.
  Section numerals render as navy grid cells; serif display type is replaced
  by heavy-weight sans throughout.
- Dark theme gains layered blue-black surfaces and a dark-specific cover
  treatment. Print output neutralizes the cover to ink-on-white; reduced-motion
  disables the rule animation; RTL mirrors the cover pattern and rule.

### Added
- **Light/dark theme switch.** A toggle in the sticky top bar lets readers
  switch between the built theme and the dark theme at any time. Charts,
  the profile table, and map point colors re-skin immediately, and the
  choice persists across reopenings when browser storage is available.
  Dashboards built with `theme(dark)` start dark and can be switched to
  light. Interface strings are localized in English, Arabic, and Urdu.
- **Shareable view links.** The active filters, the weighted/unweighted
  switch, the currency switch, and the search query are mirrored into the
  page URL. A **Copy view link** button in the control bar copies a link
  that reopens the dashboard in exactly the same state — useful when
  circulating a specific subgroup view by email or chat.
- **Filtered-data CSV export.** A **Download data (CSV)** button exports
  the currently filtered interviews. Categorical codes are written using
  their questionnaire labels, multi-select answers are joined with
  semicolons, the weight column is appended when the dashboard is
  weighted, and a UTF-8 byte-order mark keeps Excel rendering correct.
  Only data already embedded in the file is exported, so the feature adds
  no new disclosure surface.
- **Per-chart PNG export.** Each panel gains a small download control that
  saves the chart — composited on the current card background with the
  panel title — as a PNG named after the variable.
- **Expand all / Collapse all.** Two buttons at the end of the sticky
  section navigation open or close every section at once; helpful on
  large instruments built with `maxpanels(0)`.
- **Back-to-top button and reading-progress bar.** A floating
  return-to-top control appears after scrolling, and a thin cyan-to-gold
  progress bar under the top bar shows position within the document. Both
  are RTL-aware and hidden in print.
- **Keyboard shortcuts.** `/` opens the controls and focuses the
  indicator search from anywhere on the page; `Escape` clears an active
  search.

### Changed
- Chart palette colors are re-read from CSS custom properties whenever the
  theme changes, instead of being captured once at load.
- Editorial finish refinements: a restrained cyan/gold hero glow, gentle
  hover elevation on panels and KPI cards, softer section-summary hover
  states, styled thin scrollbars on internal scroll regions, and a
  brand-tinted text-selection color. All motion respects
  `prefers-reduced-motion`, and the new controls are excluded from print
  output.

### Packaging
- Version contract updated throughout: `surveye.pkg`, `stata.toc` layout,
  `MANIFEST.MF`, the ado wrapper, the help file, and the release checks
  now reference 2.2.0 and `surveye_2_2_0.jar`.

### Added

- Added the survey-agnostic `editorial` theme, now the default, based on the
  warm paper canvas, World Bank role colors, serif hierarchy, softened cards,
  and restrained finishing of the generic informality dashboard.
- Added independent `background()`, `typography()`, `corners()`, `shadow()`,
  `motion()`, and `pagewidth()` presentation controls for build and demo mode.
- Added a reduced-motion-safe Java appearance post-processor, portable tests,
  and a refreshed bundled example dashboard.

### Changed

- Removed the separate Survey Solutions branding and embedded-data strip, including its top rule, from every generated dashboard theme. The dashboard now begins directly with its main header and navigation.

### Compatibility

- Explicit `theme(worldbank)`, `theme(clean)`, `theme(forest)`, and
  `theme(dark)` retain their previous appearance unless a new layer option is
  supplied.  Appearance processing does not alter data, chart calculations,
  filters, weights, currency conversion, tables, or maps.

## [2.1.3] — 2026-07-21

### Added

- Added a runtime **Weighted estimates** switch whenever a native Stata weight
  is supplied.  Weighted results remain the default; readers can recalculate
  charts, comparisons, numeric summaries, and profile tables without weights
  while raw sample counts remain unchanged.
- Added a local-currency/USD switch configured by `usdvars()`, `usdrate()`, and
  `currency()`.  Local currency remains the default, and one documented fixed
  rate updates declared monetary charts, Stats, and profile-table summaries.
- Added a responsive side-by-side profile table configured by `tableby()` and
  `tablevars()`, with `auto`, `share`, explicit-code share, mean, median, and
  sum columns; optional column labels, title, subtitle, all-group reference
  label, and weighted-total heading; and live filter, weight, and currency
  refresh.  The table ignores only its own grouping filter so all comparison
  rows and the reference benchmark remain visible.

### Changed

- Removed Tukey fences, outlier counts, weighted outlier mass/share, whisker
  boxes, tail annotations, and outlier-specific colors from numeric cards.
- Numeric distributions now retain every valid measurement across their full
  plotted range.  A single dotted `Mean + 3 SD` reference is drawn only when
  the standard deviation is positive and the reference lies strictly inside
  that range.
- Kept wide integer supports readable with automatic equal-width,
  integer-aligned bins and regular numeric ticks, independently of
  `maxcategories()`.

### Fixed

- Recalculated every numeric Stats table from the current filtered rows even
  while its Stats tab is open and the lazily rendered chart canvas is hidden.
- Applied the same live filter refresh to unweighted and weighted summaries,
  including valid/missing counts, moments, quantiles, and the 3-SD reference.

## [2.1.2] — 2026-07-20

### Changed

- Made integer distributions independent of `maxcategories()`.  Exact bars and
  zero-frequency gaps are retained while readable; wider supports now use
  equal-width, integer-aligned bins automatically.
- Replaced categorical histogram axes with numeric linear axes and regular
  round-number ticks for both discrete and continuous distributions.
- Kept complete summary statistics while preventing extreme Tukey tails from
  flattening the visible distribution; low/high tail counts are shown at the
  corresponding plot edges.

### Fixed

- Prevented isolated extreme positive values from expanding an integer chart
  into hundreds of empty bars and producing labels such as `18, 79, 140, ...`.
- Added Arabic and Urdu interface text for smart integer bins, display ranges,
  and outlier-tail annotations.

## [2.1.1] — 2026-07-20

### Fixed

- Fixed quoted `comparelevels()` values in Stata.  Options such as
  `comparelevels("Male|Female")` now reach the engine as the two display labels
  `Male` and `Female`, instead of the literal fragments `"Male` and `Female"`.
- Fixed the same outer-quote handling for documented `vargroups("Title:: ...")`
  specifications.
- Added engine-side defensive quote normalization and regression coverage for
  labeled numeric comparison groups and quoted manual families.

## [2.1.0] — 2026-07-20

### Added

- Added automatic related-variable families for compatible binary letter-suffix items such as `srib8a srib8b srib8c`. Added `vargroups()`, `ungroupvars()`, and `noautogroups` for explicit placement, opt-out, and manual grouping.
- Added `compare()` with required `compareby()`, optional `comparetitle()`, and `comparelevels()` for full-width grouped horizontal comparisons of up to 12 binary indicators across two to five subgroups.
- Added exact-value displays for small integer counts and `discrete()`, `continuous()`, and `noautodiscrete` controls. Discrete charts retain zero-frequency integer gaps, show a weighted median, flag Tukey outliers, and keep a complete Stats tab.

### Changed

- Gave grouped families and comparisons a symmetric full-width layout with direct percentage labels, stable colors, subgroup-specific valid denominators, and native Stata-weight support.
- Kept confidence intervals off binary family and subgroup-comparison panels, including when `ci` is requested; ordinary eligible categorical bars retain opt-in intervals.
- Balanced incomplete card rows into deliberate three-, two-, or one-card compartments and retained compact chart heights.
- Replaced the tall sticky filter block with a compact disclosure toolbar that starts collapsed and preserves active filters when closed.
- Set normal Chart.js transitions to 800 milliseconds and delayed chart construction until a panel is visible so animations do not finish offscreen. Reduced-motion users still receive no animation.

### Fixed

- Replaced Survey Solutions' generic calculated-variable labels with actual variable names when no meaningful label exists.
- Excluded questionnaire-declared negative special codes and configured missing codes from numeric distributions, medians, statistics, outlier detection, and numeric filter choices while retaining them in categorical figures.
- Corrected custom numeric value-label lookup so attached label definitions no longer raise Stata `r(111)`.
- Applied `maxpanels()` only after family construction so a grouped panel is never split, and made explicit comparisons take precedence over automatic grouping.

### Compatibility

- Existing 2.0 syntax remains valid. Automatic grouping is conservative and affects only compatible binary suffix families; use `noautogroups` to retain one panel per variable.

## [2.0.0] — 2026-07-20

### Added

- Added complete English, Arabic, and Urdu dashboard-interface dictionaries, including controls, chart summaries, numeric statistics, map text, empty/error states, and footer explanations.
- Added `uilanguage(auto|english|arabic|urdu)`, with `en`, `ar`, and `ur` aliases. Automatic resolution gives priority to declared `ar`/`ur`, then detects Urdu-specific or other Arabic-script questionnaire text, and otherwise selects English.
- Added `direction(auto|ltr|rtl)`. Automatic direction follows the resolved interface language—Arabic and Urdu use right-to-left, while English uses left-to-right; an explicit direction overrides layout without changing the selected interface language.
- Added localized HTML `lang` and `dir` metadata and right-to-left component behavior for navigation, controls, cards, charts, tables, tooltips, and Leaflet controls.
- Expanded documentation and examples for all four native Stata weight forms: `[aw=wmedian]`, `[fw=frequency]`, `[iw=importance]`, and `[pw=pop]`.
- Added keyboard-operable point markers to Leaflet maps. Every individual point exposes a localized accessible label and opens its popup with Enter or Space.
- Added weighted Tukey-outlier mass and share to the numeric Stats tab, alongside the raw outlier count.
- Added the `ci` flag for opt-in pointwise Wilson intervals on ordinary categorical and multiselect horizontal bars. `level(#)` requires `ci` and defaults to 95 when intervals are requested.

### Changed

- **Breaking:** adopted the SurvEye product name and renamed the Stata command
  and distribution package from the former `suso_dashboard` name (and interim
  `surveydash` preview) to `surveye`. The installed entry points are now
  `surveye.ado`, `surveye.sthlp`, `surveye.pkg`, `surveye.jar`, and
  `surveye_2_0_0.jar`. Existing do-files must replace the former command name.
- Clarified that weights use Stata's native bracket syntax after the `using` filename and before the comma; there is no `weight()` option.
- Added native importance-weight support for descriptive estimates. Because iweights have no general sampling interpretation, requested confidence intervals are suppressed automatically with an explanatory note.
- Standardized weight validation: one numeric variable is allowed, negatives are rejected, fweights must be integers, and zero or missing weights are excluded from the analysis sample for every weight type.
- Changed confidence intervals from automatic to opt-in so dense dashboards remain visually clear. Binary yes/no, answered/missing completion, and donut cards never display CI text or whiskers, even when `ci` is supplied.
- Retained the compact visuals, custom-variable placement, optional confidence intervals, outlier-aware Stats tab, and Leaflet/Google map behavior introduced in 1.2.0.
- Localized generated Additional indicators, Other indicators, and untitled Key message headings instead of leaving English fallback text in Arabic or Urdu dashboards.

### Fixed

- Corrected the public and parser-facing weight order to Stata's `using questionnaire.html [weight], options` grammar and added a static regression guard for every shipped example.
- Preserved date formats and missing/special metadata for custom, filter-only, and highlight variables, including the `maxcategories(12)` boundary with 12 valid filter levels plus an excluded code.
- Corrected dark-theme chart, brand, and numeric-tab contrast and kept percentage/share demo values in their natural 0–100 range.
- Serialized affirmative and negative response codes from the Java parser so Turkish, Russian, Chinese, Japanese, Arabic, Urdu, Sinhala, and other recognized binary labels receive the correct colors without relying on a narrower browser-side translation list.
- Made histogram outlier counts readable, used theme-aware donut separators and confidence-interval halos, darkened labels placed inside light blue bars, fixed the map legend text token, and forced dark dashboards to print on a light background.
- Made filters type-aware and observed-value-only: numeric comparisons are normalized, multiselect filters match any selected valid option, completion filters distinguish answered from missing, and configured missing codes never become filter choices.
- Kept GPS rows whose `mapby()` value is configured missing as visible ungrouped points while excluding those values from map legends and category limits.
- Fully mirrored horizontal bar axes and direct-value labels in RTL layouts, and hardened category, filter, navigation, and map dictionaries so legitimate values such as `__proto__`, `constructor`, and `toString` cannot corrupt dashboard state.
- Embedded the applicable Chart.js, Leaflet, and Noto Sans Arabic license notices in each standalone HTML output and documented that the keyless Google tile URLs are unofficial compatibility endpoints whose availability and terms may change.
- Made Reset all clear the indicator search as well as response-filter choices, and refreshed visible charts and Leaflet sizing after the controls panel changes height.

### Compatibility

- The questionnaire/data workflow and dashboard options remain otherwise compatible with 1.2.0. The command/package rename is the intentional major-version break.
- Requested weighted confidence intervals remain descriptive: frequency weights use weighted counts, analytic and probability weights use a labelled Kish effective-sample-size approximation rather than design-based survey variance estimation, and importance weights suppress intervals.

## [1.2.0] — 2026-07-15

### Added

- Added `customvars()` for variables present in the Stata data but absent from the questionnaire. Custom charts use the Stata variable label by default and infer categorical, numeric, or date behavior from storage type, supported `%tc`/`%td`/`%tw`/`%tm`/`%tq`/`%th`/`%ty` formats, and value-label metadata.
- Added `addtosections()` so declared custom variables can be placed in an existing selected section by exact title or number, or in a newly named section, without reorganizing the rest of the questionnaire.
- Added embedded Leaflet 1.9.4 map rendering with the `esqc_gps` base-layer choices: `google_hybrid`, `google_sat`, `google_road`, and `osm`.
- Added pointwise Wilson confidence intervals to categorical shares, with configurable confidence levels.
- Added a **Stats** tab to numeric cards with valid and missing counts, mean, standard deviation, extrema, quartiles, median, Tukey fences, and outlier counts.
- Added an outlier-aware distribution guide and histogram scale using Tukey's 1.5-IQR whisker range while retaining extreme values in numeric statistics.

### Changed

- Changed the GPS defaults to `maptype(points)` and `basemap(google_hybrid)`. Every valid observation now receives an individual circle marker; exact coordinate duplicates are separated slightly on screen so each remains selectable.
- Kept `maptype(cluster)` and `maptype(heat)` as explicit aggregated displays rather than silently combining points by default.
- Map-enabled dashboards now fetch the selected Google or OpenStreetMap tiles when opened. Leaflet, survey points, and boundary geometry remain embedded, and dashboards without maps retain no runtime network dependency.
- Updated the privacy notice to state that map-enabled files embed valid coordinates at six decimals for points, four for cluster, and three for heat. Reduced precision and visual aggregation are not presented as a substitute for formal disclosure control.
- Weighted confidence intervals now label analytic- and probability-weight results as effective-sample-size approximations and explicitly note that they are not adjusted for complex survey design.

### Fixed

- Replaced the stretched static SVG Leaflet overlay with true WGS84 boundary rings so country and Admin-2 lines align with GPS points; antimeridian countries are normalized onto one longitude branch.
- Counted expanded-multiselect respondents in the combined **Other** category once even when they selected more than one grouped response.
- Prevented extreme numeric values from flattening the main histogram while continuing to report them transparently as outliers.

## [1.1.0] — 2026-07-15

### Added

- Added `density(compact|comfortable)` so users can switch between the space-efficient default and a roomier presentation.
- Added concise, screen-reader-friendly chart summaries and reduced-motion support.

### Changed

- Redesigned the dashboard as a responsive three-, two-, or one-column grid for wide, medium, and mobile screens.
- Replaced binary and completion donuts with compact 100% split bars that display values directly.
- Made sorted horizontal bars the automatic categorical display; donut charts are now available only when explicitly requested.
- Compacted numeric histograms and date visuals, including a visible median marker for faster distribution reading.
- Collapsed optional GPS maps to a compact summary in compact mode while keeping the full interactive map one click away; comfortable mode opens maps initially.
- Strengthened responsive visual QA across desktop, tablet, mobile, overflow, accessibility-summary, and reduced-motion states.

## [1.0.4] — 2026-07-15

### Fixed

- Returned Stata numeric missing directly for mode-specific status fields that are absent or explicitly `.` instead of passing `.` to `confirm number` and raising `r(498)`.
- Guarded GPS summary formatting until all map counters are present.
- Added licensed-Stata regressions for sparse, explicit-missing, and genuinely malformed numeric status records.
- Added strict Java status-schema checks for build, demo, describe, engine-error, and bridge-linkage paths.

## [1.0.3] — 2026-07-15

### Added

- Added the fully qualified Stata plugin entry point `org.worldbank.suso.dashboard.StataPlugin` with a fallback status-file handoff for linkage failures.
- Added a release-specific `suso_dashboard_1_0_3.jar` for Stata while retaining `suso_dashboard.jar` for command-line use.

### Fixed

- Prevented an obsolete unversioned JAR earlier on the ado-path from shadowing the engine required by the current ado file.
- Replaced the absolute mixed-separator Windows JAR argument with Stata's documented `jars()` ado-path lookup.
- Preserved `javacall` loader and JVM diagnostics instead of suppressing them with `quietly`.
- Added a specific explanation for Stata `r(5100)` when the installed JAR is stale or incompatible.

## [1.0.2] — 2026-07-14

### Added

- Added an explicit `build` subcommand for datasets containing a leading variable named `describe` or `demo`.
- Added a licensed-Stata smoke do-file covering main, describe, demo, `if`, weights, all-missing rows, `showempty`, macro-safe Unicode text, output protection, and returned results.

### Fixed

- Replaced the invalid bare `tab` token in Stata `file write` with the required `_tab` directive and added a source-contract regression check.
- Protected configuration and status strings from unintended Stata macro expansion.
- Resolved abbreviated weight names before CSV export and Java configuration.
- Preserved observations missing on every selected field by exporting a noncharted analysis-sample sentinel.
- Allowed `showempty` to reach Java when no selected response column exists.
- Accepted logical questionnaire names in `exclude()` and rejected chart/exclude contradictions consistently.
- Prevented relative-path aliases and symlinks from allowing outputs or diagnostics to overwrite questionnaires, data, boundaries, logos, status files, or each other.
- Added fallback Java status reporting for configuration-read errors and clearer diagnostics for missing status files.

## [1.0.1] — 2026-07-14

### Fixed

- Corrected construction of the Stata analysis-sample marker so commands without `if`, `in`, or weights no longer stop with `__000000 not found` (`r(111)`).

## [1.0.0] — 2026-07-14

### Added

- Stata 16+ `rclass` command with main, `describe`, and `demo` modes.
- Direct, platform-independent Stata-to-Java bridge through `javacall`.
- Survey Solutions questionnaire parser designed for English, translated, legacy, and current printable HTML variants.
- Automatic and explicit variable selection, questionnaire section selection, section-title matching, exclusions, and custom sections.
- A responsive 100-panel default limit for large dashboards, with `maxpanels()` control and an unlimited opt-in.
- Logical `questions()` selection with exact and Survey Solutions multiselect-expansion export; it can be combined with the Stata `varlist`.
- Automatic chart choice plus bar, donut, and histogram overrides.
- Dashboard filters, highlight cards, key messages, titles, subtitles, notes, source lines, disclaimers, embedded logos, and four themes.
- `if`, `in`, analytic-weight, frequency-weight, and probability-weight support.
- Temporary UTF-8 raw-code CSV export containing only the variables required by the requested dashboard.
- Optional country GPS map with clustered, heat, and point displays; bundled country outlines; user-supplied WGS84 boundary ZIPs; Admin-2 support; map grouping; and coordinate QA counts.
- Self-contained offline HTML with embedded Chart.js, data, CSS, logo, and map geometry.
- Structured status exchange and documented `r()` results for automation and QA.
- Friendly input validation, strict mode, diagnostic logging, and refusal to create empty dashboards from unrecognized questionnaire files.
- Stata help, runnable example do-file, GitHub/SSC package metadata, license, and third-party notices.

### Fixed

- Matched zero-padded questionnaire option codes to Stata numeric exports while preserving genuine string categories.
- Reduced text, media, GPS-completion, and unlabeled linked text-list questions to answered/not-answered flags.
- Calculated weighted means, medians, shares, and histograms consistently, including safe handling of zero-total-weight selections.
- Distinguished unanswered expanded multiselect rows from answered all-zero rows so respondent denominators remain correct.
- Recognized ISO, Stata daily, Stata datetime, and common displayed-date forms without generating invalid demo dates.
- Omitted invalid GPS rows, kept map colors stable under filtering, and aligned map points at mobile sizes.
- Preserved negative numeric responses in histograms instead of treating every negative value as missing.
- Preserved a valid source-document language tag and used `lang="und"` when the questionnaire does not declare one.
- Removed Survey Solutions Markdown links and formatting artifacts from displayed labels.
- Added explicit `filters()` selection and metadata/cardinality checks; automatic suggestions remain conservative and language/name dependent.
- Tightened automatic filter matching to whole concepts, avoiding false matches such as `state` inside `statements` or `strat` inside `administrative`.
- Applied `maxcategories()` to bar, multiselect, and donut displays using a top-levels-plus-Other rule while preserving the full denominator.
- Replaced raw Java stack traces for common user errors with concise Stata and engine messages.
- Removed runtime dependencies on Google Fonts, CDNs, and other network services.
